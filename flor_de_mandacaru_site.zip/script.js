
const produtos = [
  { nome: "Xícara de polímero", preco: 15.00 },
  { nome: "Xícara tradicional (alça branca)", preco: 25.00 },
  { nome: "Xícara com alça colorida", preco: 35.00 },
  { nome: "Xícara alça de coração", preco: 45.00 },
  { nome: "Xícara de colher", preco: 45.00 },
  { nome: "Xícara mágica", preco: 50.00 },
  { nome: "Caixinha personalizada para xícara", preco: 7.00 },
  { nome: "Caneca de chopp jateada", preco: 50.00 },
  { nome: "Copo long drink", preco: 4.50 },
  { nome: "Kit copo long drink (20 unid)", preco: 80.00 },
  { nome: "Caneca de acrílico 300 ml", preco: 5.00 },
  { nome: "Kit caneca (20 unid)", preco: 85.00 },
  { nome: "Copo americano acrílico", preco: 4.50 },
  { nome: "Kit copo americano (20 unid)", preco: 80.00 },
  { nome: "Camisa branca personalizada", preco: 28.00 },
  { nome: "Camisa colorida (claras)", preco: 32.00 },
  { nome: "Camisa colorida (escuras, 10+ unid)", preco: 38.00 },
  { nome: "Camisa pintura 100% (10+ unid)", preco: 50.00 },
  { nome: "Petisqueira personalizada", preco: 30.00 },
  { nome: "Táboa de carne personalizada", preco: 50.00 }
];

const grid = document.querySelector(".grid");
const carrinho = [];
const listaCarrinho = document.getElementById("itens-carrinho");
const totalSpan = document.getElementById("total");
const linkFinalizar = document.getElementById("finalizar");

produtos.forEach((produto, i) => {
  const div = document.createElement("div");
  div.className = "produto";
  div.innerHTML = `
    <h4>${produto.nome}</h4>
    <p>R$ ${produto.preco.toFixed(2)}</p>
    <button onclick="adicionar(${i})">Adicionar</button>
  `;
  grid.appendChild(div);
});

function adicionar(i) {
  carrinho.push(produtos[i]);
  atualizarCarrinho();
}

function atualizarCarrinho() {
  listaCarrinho.innerHTML = "";
  let total = 0;
  carrinho.forEach((item) => {
    const li = document.createElement("li");
    li.textContent = `${item.nome} - R$ ${item.preco.toFixed(2)}`;
    listaCarrinho.appendChild(li);
    total += item.preco;
  });
  totalSpan.textContent = `Total: R$ ${total.toFixed(2)}`;
  const mensagem = carrinho.map(p => `• ${p.nome} - R$ ${p.preco.toFixed(2)}`).join('%0A');
  linkFinalizar.href = `https://wa.me/5574885215788?text=Olá! Gostaria de fazer um pedido:%0A${mensagem}%0ATotal: R$ ${total.toFixed(2)}`;
}
